#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>

struct node {
    int key;
    int height;
    struct node *left;
    struct node *right;
};

struct stack {
    int top;
    int max;
    char *str;
};

struct node *createnode(int key) {
    struct node *newnode = (struct node *)malloc(sizeof(struct node));
    newnode->key = key;
    newnode->left = NULL;
    newnode->right = NULL;
    newnode->height = 0; 
    return newnode;
}

struct stack *createstack(int n) {
    struct stack *newstack = (struct stack *)malloc(sizeof(struct stack));
    newstack->top = -1;
    newstack->max = n;
    newstack->str = (char *)malloc(n * sizeof(char));
    return newstack;
}

int isempty(struct stack *stack) {
    return (stack->top == -1);
}

void push(struct stack *stack, char k) {
    if (stack->top == stack->max - 1)
        return;
    stack->str[++stack->top] = k;
}

char pop(struct stack *stack) {
    if (isempty(stack))
        return '\0';
    return stack->str[stack->top--];
}

char peek(struct stack *stack) {
    if (isempty(stack))
        return '\0';
    return stack->str[stack->top];
}

int max(int a, int b) {
    return (a > b) ? a : b;
}

int height(struct node *node) {
    if (node == NULL)
        return -1;
    return node->height;
}

int getbalance(struct node *node) {
    if (node == NULL)
        return 0;
    return height(node->left) - height(node->right);
}

struct node *rightrotate(struct node *y) {
    struct node *x = y->left;
    struct node *xr = x->right;

    x->right = y;
    y->left = xr;

    y->height = 1 + max(height(y->left), height(y->right));
    x->height = 1 + max(height(x->left), height(x->right));

    return x;
}

struct node *leftrotate(struct node *y) {
    struct node *x = y->right;
    struct node *xl = x->left;

    x->left = y;
    y->right = xl;

    y->height = 1 + max(height(y->left), height(y->right));
    x->height = 1 + max(height(x->left), height(x->right));

    return x;
}

void insert(struct node **node, int key) {
    if (*node == NULL) {
        *node = createnode(key);
        return;
    }
    if (key < (*node)->key) {
        insert(&((*node)->left), key);
    } else if (key > (*node)->key) {
        insert(&((*node)->right), key);
    } else {
        return;
    }
    (*node)->height = 1 + max(height((*node)->left), height((*node)->right));
    int balance = getbalance(*node);

    if (balance > 1) {
        if (key < (*node)->left->key) {
            *node = rightrotate(*node);
        } else if (key > (*node)->left->key) {
            (*node)->left = leftrotate((*node)->left);
            *node = rightrotate(*node);
        }
    } else if (balance < -1) {
        if (key > (*node)->right->key) {
            *node = leftrotate(*node);
        } else if (key < (*node)->right->key) {
            (*node)->right = rightrotate((*node)->right);
            *node = leftrotate(*node);
        }
    }
}

int indexcheck(char str[], int start, int end) {
    if (start > end)
        return -1;
    struct stack *st = createstack(end - start + 1);
    for (int i = start; i <= end; i++) {

        if (str[i] == '(') {
            push(st, str[i]);

        } else if (str[i] == ')') {
            if (!isempty(st) && peek(st) == '(') {
                pop(st);
                if (isempty(st)) {
                    int result = i;
                    free(st->str);
                    free(st);
                    return result;
                }
            }
        }
    }
    free(st->str);
    free(st);
    return -1;
}

struct node *buildtree(char str[], int start, int end) {
    if (start > end)
        return NULL;

    int no = 0;


    if (str[start] >= '0' && str[start] <= '9') {
        while (start <= end && str[start] >= '0' && str[start] <= '9') {
            no = no * 10 + (str[start] - '0');
            start++;
        }
    }

    struct node *root = createnode(no);

    int ind = -1;

    if (start <= end && str[start] == '(') {
        ind = indexcheck(str, start, end);
    }

    if (ind != -1) {
        root->left = buildtree(str, start + 1, ind - 1);
        root->right = buildtree(str, ind + 2, end - 1);
    }

    return root;
}

struct node *search(struct node *node,int key){
    if(node==NULL)
        return NULL;
    if(key==node->key)
        return node;

    if(key < node->key)
        return search(node->left,key);

    else if(key > node->key)
        return search(node->right,key);  
}

struct node *successor(struct node *root,int key){
    struct node *temp=search(root,key);
    if(temp==NULL)
        return NULL;
    
    if(temp->right!=NULL){
        temp=temp->right;
    while(temp->left!=NULL){
        temp=temp->left;
    }
    return temp;
    }

    struct node *suc=NULL;
    struct node *anc=root;
    while(anc!=NULL && anc !=temp){
        if(temp->key < anc->key){
            suc=anc;
            anc=anc->left;
        }
        else
            anc=anc->right;
    }
    return suc;
}

void sucpath(struct node *root,int key){
    struct node *k=successor(root,key);
    struct node *temp=root;
    if(k==NULL)
        printf("%d",height(root));
    else{
        while(temp!=NULL){
            printf("%d ",temp->key);
        if(k->key < temp->key)
            temp=temp->left;
        else if(k->key > temp->key)
            temp=temp->right;
        else
        break;
        }
    }
    printf("\n");
}

int sumin(struct node *root){
    int sum=0;
    if(root!=NULL){
        sum=sum+sumin(root->left);
        sum=sum+root->key;
        sum=sum+ sumin(root->right);
    }
    return sum;
}
void subtreesum(struct node *root,int key){
    struct node *temp=search(root,key);
    if(temp==NULL)
        printf("-1");
    else{
        printf("%d ",sumin(temp));
    }
}
void elements(struct node *node,int *length,int a[]){
    if(node==NULL)
        return;
    elements(node->left,length,a);
    a[(*length)++]=node->key;
    elements(node->right,length,a);
}
    
int closest(struct node *node, int key) {
    struct node *temp = search(node, key);
    if (temp == NULL)
        return -1;

    int a[1000];
    int length = 0;
    int diff = INT_MAX;
    int closest_key = -1;

    elements(node, &length, a); 
    for (int i = 0; i < length; i++) {
        int check = abs(key - a[i]);
        if (check < diff && a[i] != key) {
            diff = check;
            closest_key = a[i];
        }
    }
    return closest_key;
}
void finddelete(struct node **node, int *len, int l, int u, int a[]) {
    if (*node == NULL)
        return;

    if ((*node)->key >= l && (*node)->key <= u)
        a[(*len)++] = (*node)->key;

    finddelete(&((*node)->left), len, l, u, a);
    finddelete(&((*node)->right), len, l, u, a);
}

struct node *minvalue(struct node **node) {
    while ((*node)->left != NULL) {
        *node = (*node)->left;
    }
    return *node;
}

struct node *deletenode(struct node **node, int key) {
    if (*node == NULL)
        return *node;

    if (key < (*node)->key) {
        (*node)->left = deletenode(&((*node)->left), key);
    } else if (key > (*node)->key) {
        (*node)->right = deletenode(&((*node)->right), key);
    } else {
        if ((*node)->left == NULL && (*node)->right == NULL) {
            free(*node);
            *node = NULL;
        } else if ((*node)->left == NULL) {
            struct node *temp = (*node)->right;
            free(*node);
            *node = temp;
        } else if ((*node)->right == NULL) {
            struct node *temp = (*node)->left;
            free(*node);
            *node = temp;
        } else {
            struct node *temp = minvalue(&((*node)->right));
            (*node)->key = temp->key;
            (*node)->right = deletenode(&((*node)->right), temp->key);
        }
    }

    if (*node == NULL)
        return *node;

    (*node)->height = 1 + max(height((*node)->left), height((*node)->right));
    int balance = getbalance(*node);

    if (balance > 1) {
        if (key < (*node)->left->key) {
            return rightrotate(*node);
        } else if (key > (*node)->left->key) {
            (*node)->left = leftrotate((*node)->left);
            return rightrotate(*node);
        }
    } else if (balance < -1) {
        if (key > (*node)->right->key) {
            return leftrotate(*node);
        } else if (key < (*node)->right->key) {
            (*node)->right = rightrotate((*node)->right);
            return leftrotate(*node);
        }
    }

    return *node;
}

int delete(struct node **node, int l, int u) {
    int a[1000];
    int len = 0;
    int count = 0;
    
    finddelete(node, &len, l, u, a);

    if (len == 0)
        return -1;

    for (int i = 0; i < len; i++) {
        *node = deletenode(node, a[i]);
        count++;
    }

    return count;
}

void preorder(struct node *node){
    if(node==NULL)
        return;
    printf("%d ",node->key);
    preorder(node->left);
    preorder(node->right);
}
void print(struct node *node){
    if(node==NULL)
        return;
    
    printf("%d",node->key);

    if(node->left==NULL && node->right==NULL){
        return;
    }
    printf(" ( ");
    if(node->left!=NULL){
        print(node->left);
    }
    if(node->left==NULL)
        printf("");
    printf(" ) ");

    if(node->right!=NULL){
        printf(" ( ");
        print(node->right);
        printf(" )");
    }
}
int main() {
    char c;
    char istr[1000];
    char ostr[1000];
    int x;
    int t;
    int y;
    struct node *temp1;
    struct node *temp2;
    scanf(" %[^\n]", istr);
    for(int i=0;i < strlen(istr); ++i){
        if(istr[i]==' ')
            continue;
        else{
            ostr[t]=istr[i];
            t++;
        }
    }
    ostr[t]='\0';
    struct node *root = buildtree(ostr, 0, strlen(ostr) - 1);
    do {
        scanf(" %c", &c);
        switch (c) { 
            case 'a':
                while (scanf("%d", &x) == 1) {
                    insert(&root, x);
                    if(getchar()=='\n')
                    break;
                }
                print(root);
                printf("\n");
                break;
                
            case 'b':
            scanf("%d %d",&x,&y);
            int count=delete(&root,x,y);
            printf("%d ",count);
            if(count!=0)
                preorder(root);
            printf("\n");
            break;
            
            case 'c':
            scanf("%d",&x);
            sucpath(root,x);
            break;

            case 'd':
            scanf("%d",&x);
            struct node *temp1=search(root,x);
            subtreesum(root,x);
            print(temp1);
            printf("\n");
            break;

            case 'e':
            scanf("%d",&x);
            y=closest(root,x);
            printf("%d\n",y);
            break;
        }
    } while (c != 'g');
    return 0;
}