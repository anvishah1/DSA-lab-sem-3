#include <stdio.h>
#include <stdlib.h>

struct node{
    int key;
    int value;
    struct node *left;
    struct node *right;
    int height;
};

struct node *createnode(int key,int val){
    struct node *newnode=(struct node* )malloc(sizeof(struct node));
    newnode->key=key;
    newnode->value=val;
    newnode->left=NULL;
    newnode->right=NULL;
    newnode->height=0;
    return newnode;
}

int height(struct node *node){
    if(node==NULL)
        return -1;
    return node->height;
}

int max(int a,int b){
    if(a>b)
        return a;
    else
        return b;
}

int getbalance(struct node *node){
    if(node==NULL)
        return 0;
    else
    return (height(node->left)-height(node->right));
}

struct node *rightrotate(struct node *y){
    struct node *x=y->left;
    struct node *xr=x->right;

    x->right=y;
    y->left=xr;

    y->height=1+(max(height(y->left),height(y->right)));
    x->height=1+(max(height(x->left),height(x->right)));

    return x;
}

struct node *leftrotate(struct node *y){
    struct node *x=y->right;
    struct node *xl=x->left;

    x->left=y;
    y->right=xl;

    y->height=1+(max(height(y->left),height(y->right)));
    x->height=1+(max(height(x->left),height(x->right)));

    return x;
}

struct node *insert(struct node *node,int key,int val){
    if(node==NULL)
        return (createnode(key,val));

    if(key< node->key)
    node->left=insert(node->left,key,val);
    else if(key > node->key)
    node->right=insert(node->right,key,val);
    else if(key==node->key)
        node->value=val;
    else
    return node;

    node->height=1+(max(height(node->left),height(node->right)));

    int balance= getbalance(node);
    if(balance > 1){
        if(key < node->key)
            return rightrotate(node);
        else if(key > node->key){
            node->left=leftrotate(node->left);
            return rightrotate(node);
        }
    }
    else if(balance < -1){
        if(key > node->right->key)
        return leftrotate(node);
        else if(key < node->right->key){
            node->right=rightrotate(node->right);
            return leftrotate(node);
        }
    }
    return node;
}

struct node *find(struct node *node,int key){
    if(node==NULL)
        return NULL;
    while(node!=NULL && node->key!=key){
        if(key < node->key)
            node=node->left;
        else
            node=node->right;
    }
    if(node!=NULL && node->key==key)
        return node;
    else if(node==NULL)
        return NULL;
}

void empty(struct node *node){
    if(node==NULL)
    printf("1\n");
    else
    printf("0\n");
}

void display(struct node *node){
    if(node==NULL) 
        return;
    display(node->right);
    printf("%d ",node->key);
    display(node->left);
}

int size(struct node *node){
    if(node==NULL)
        return 0;
   int lefttree= size(node->left);
    int righttree=size(node->right);
    int treesize = 1+lefttree+ righttree;
    return treesize;
}

struct node *min(struct node *node){
    while(node->left!=NULL){
        node=node->left;
    }
    return node;
}

struct node *upper(struct node *node,int key){
    if(node==NULL)
        return NULL;
    struct node *temp=find(node,key);
    if(temp!=NULL)
        return temp;
    else if(temp==NULL){
        while(node!=NULL && key > node->key){
            node=node->right;
        }
        if(node!=NULL)
            return min(node);
        else if(node==NULL)
            return NULL;
    }
}

int main(){
    struct node *node=NULL;
    int key;
    int val;
    int x;
    struct node *temp;
    char c;
    do{
        scanf(" %c",&c);
        switch(c){
            case 'i':
            scanf("%d %d",&key,&val);
            node=insert(node,key,val);
            break;

            case 'f':
            scanf("%d",&key);
            temp=find(node,key);
            if(temp==NULL)
                printf("-1\n");
            else
            printf("%d %d\n",temp->key,temp->value);
            break;

            case 's':
            x=size(node);
            printf("%d\n",x);
            break;

            case 'e':
            empty(node);
            break;

            case 'u':
            scanf("%d",&key);
            temp=upper(node,key);
            if(temp==NULL)
                printf("-1\n");
            else
                printf("%d %d\n",temp->key,temp->value);
            break;

            case 'd':
            display(node);
            printf("\n");
            break;

            case 't':
            break;
        }
    }while(c!='t');
}