#include <stdio.h>
#include <stdlib.h>

struct node{
    int key;
    int height;
    struct node *left;
    struct node *right;
};

struct node *createnode(int val){
   struct node *newnode=(struct node *)malloc(sizeof(struct node));
   newnode->key=val;
   newnode->left=NULL;
   newnode->right=NULL;
   newnode->height=0; 
   return newnode;
}

int height(struct node *node){
if(node==NULL)
    return -1;
return(node->height);
}

int max(int a,int b){
    if(a>b)
        return a;
    else
        return b;
}

int getbalance(struct node *node){
    if(node==NULL)
        return 0;
    else
        return ((height(node->left))-height(node->right));

}

struct node* rightrotate(struct node *y){
    struct node *x=y->left;
    struct node *xr=x->right;

    x->right=y;
    y->left=xr;

    y->height= 1+ max(height(y->left),height(y->right));
    x->height= 1+ max(height(x->left),height(x->right));

    return x;
}

struct node *leftrotate(struct node *y){
    struct node *x=y->right;
    struct node *xl=x->left;

    x->left=y;
    y->right=xl;

    y->height= 1+ max(height(y->left),height(y->right));
    x->height= 1+ max(height(x->left),height(x->right));

    return x;
}

struct node *insert(struct node *node,int val,int *lc,int *rc){
    if(node==NULL)
        return (createnode(val));

    if(val< node->key)
        node->left=insert(node->left,val,lc,rc);
    else if(val> node->key)
        node->right=insert(node->right,val,lc,rc);
    else
    return node;

node->height=1 + max(height(node->left),height(node->right));
int balance=getbalance(node);

if(balance > 1){
    if(val < node->left->key){
        *rc=*rc+1;
        return rightrotate(node);
    }
    else if(val > node->left->key){
        *lc=*lc+1;
        *rc=*rc+1;
        node->left=leftrotate(node->left);
        return rightrotate(node);
    }
}
else if(balance < -1){
    if(val > node->right->key){
        *lc=*lc+1;
        return leftrotate(node);
    }
    else if(val < node->right->key){
        *rc=*rc+1;
        *lc=*lc+1;
        node->right=rightrotate(node->right);
        return leftrotate(node);
    }
}

return node;
}

struct node *search(struct node *node,int val){
    if(node==NULL)
        return NULL;
    while(node!=NULL && node->key!=val){
        if(val > node->key)
            node=node->right;
        else
            node=node->left;
    }
    if(node!=NULL && node->key==val)
        return node;
    if(node==NULL)
        return NULL;
}


void postorder(struct node *node){
    if(node==NULL)
        return;
    postorder(node->left);
    postorder(node->right);
    printf("%d ",node->key);
}

int findpath(struct node *node,int a[],int *pathlen,int key){
    if(node==NULL)
        return 0;

    a[(*pathlen)++]=node->key;

    if(key==node->key)
    return 1;

    if(findpath(node->left,a,pathlen,key) || findpath(node->right,a,pathlen,key))
        return 1;
    
    (*pathlen)--;
        return 0;
}


void path(struct node *node,int key){
    int a[1000];
    int pathlength=0;

    if(findpath(node,a,&pathlength,key)){
        for(int i=0;i<pathlength;i++)
            printf("%d ",a[i]);
    }
    else
        printf("-1");
    printf("\n");
    
}

void deletepath(struct node *node,int key){
    int b[1000];
    int length=0;
    if(findpath(node,b,&length,key)){
        for(int i=length-1; i>=0;i--){
            printf("%d ",b[i]);
        }
}
else
    printf("-1");
printf("\n");
}
struct node *minvalue(struct node *node){
    struct node *current= node;
    while(current->left!=NULL){
        current=current->left;
    }
    return current;
}

struct node *deletenode(struct node *node,int key){
    if(node==NULL)
        return node;
    if(key < node->key)
        node->left=deletenode(node->left,key);
    else if(key > node->key)
        node->right=deletenode(node->right,key);
    else{
        if(node->left==NULL && node->right==NULL){
            free(node);
            node=NULL;
        }else if(node->left==NULL){
            struct node*temp=node->right;
            free(node);
            node=temp;
        }else if(node->right==NULL){
            struct node *temp=node->left;
            free(node);
            node=temp;
        }else{
            struct node*temp=minvalue(node->right);
            node->key=temp->key;
            node->right=deletenode(node->right,temp->key);
        }
    }
    if(node==NULL)
        return node;
    node->height=1+max(height(node->left),height(node->right));
    int balance=getbalance(node);
    
    if(balance >1){
        if(key < node->left->key){
        return rightrotate(node);
    }
    else if(key > node->left->key){
        node->left=leftrotate(node->left);
        return rightrotate(node);
    }
}
else if(balance < -1){
    if(key > node->right->key){
        return leftrotate(node);
    }
    else if(key < node->right->key){
        node->right=rightrotate(node->right);
        return leftrotate(node);
    }
}
 return node;
}


int main(){
    struct node *node=NULL;
    char c;
    int val;
    int leftcount=0;
    int rightcount=0;
    struct node *temp;
    int x;
    do{
        scanf(" %c",&c);
        switch(c){

            case 'i':
            scanf("%d",&val);
            node=insert(node,val,&leftcount,&rightcount);
            break;

            case 'b':
            scanf("%d",&val);
            temp=search(node,val);
            x=getbalance(temp);
            printf("%d\n",x);
            break;
            
           case 's':
           printf("%d %d\n",leftcount,rightcount);
           break;


           case 'p':
           postorder(node);
           printf("\n");
           break;

           case 'f':
           scanf("%d",&val);
           path(node,val);
           break;
           
           case 'd':
           scanf("%d",&val);
           deletepath(node,val);
           deletenode(node,val);
           break;

           case 'e':
           break;
        }
    }while(c!='e');
}