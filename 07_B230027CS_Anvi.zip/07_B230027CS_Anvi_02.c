#include <stdio.h>
#include <stdlib.h>
#define INF 1000

int comparator(const void* a, const void *b) {
    const int(*x)[3] = a;
    const int(*y)[3] = b;
    return (*x)[2] - (*y)[2];
}

void initialise(int p[], int rank[], int n) {
    for (int i = 0; i < n; i++) {
        p[i] = i;
        rank[i] = 0;
    }
}

int findp(int p[], int comp) {
    if (p[comp] == comp) 
        return comp;
    return p[comp] = findp(p, p[comp]);
}

void unionset(int u, int v, int p[], int rank[], int n) {
    u = findp(p, u);
    v = findp(p, v);

    if (rank[u] > rank[v])
        p[v] = u;
    else if (rank[v] > rank[u])
        p[u] = v;
    else {
        p[v] = u;
        rank[u]++;
    }
}

int kruskals(int edge_count, int edge[edge_count][3], int n) {
    qsort(edge, edge_count, sizeof(edge[0]), comparator);


    int p[n];
    int rank[n];

    initialise(p, rank, n);

    int finalweight = 0;

    for (int i = 0; i < edge_count; i++) {
        int u = findp(p, edge[i][0]);
        int v = findp(p, edge[i][1]);
        int weight = edge[i][2];

        if (u != v) {
            unionset(u, v, p, rank, n);
            finalweight = finalweight + weight;
        }
    }
    return finalweight;    
}

int main() {
    int n;
    scanf("%d", &n);

    int **adj = (int **)malloc(n * sizeof(int *));
    for (int i = 0; i < n; i++) {
        adj[i] = (int *)malloc(n * sizeof(int));
        for (int j = 0; j < n; j++){
            adj[i][j] = 0; 
        }
    }

    // Reading adjacency information
    for (int i = 0; i < n; i++) {
        int start;
        scanf("%d", &start);
        int adjv;
        while (scanf("%d", &adjv) == 1) {
            adj[start][adjv] = 1;
            if (getchar() == '\n') 
                break;
        }
    }


    for (int i = 0; i < n; i++) {
        int start;
        scanf("%d", &start);
        for (int j = 0; j < n; j++) {
            if (adj[start][j] == 1) {
                int weight;
                scanf("%d", &weight);
                adj[start][j] = weight;
            }
            else{
                adj[start][j]=INF;
            }
        }
    }

    // Counting edges
    int edge_count = 0;
    for (int i = 0; i < n; i++) {
        for (int j = i + 1; j < n; j++) {
            if (adj[i][j] != INF){
                edge_count++;
            }
        }
    }

    // Allocating edges array
    int edge[edge_count][3];
    int k = 0;
    for (int i = 0; i < n; i++) {
        for (int j = i+1;j < n; j++) {
            if (adj[i][j] != INF) {
                edge[k][0] = i;
                edge[k][1] = j;
                edge[k][2] = adj[i][j];
                k++;
            }
        }
    }

    // Running Kruskal's algorithm
    int fweight = kruskals(edge_count, edge, n);
    printf("%d\n", fweight);

    // Free allocated memory
    for (int i = 0; i < n; i++) {
        free(adj[i]);
    }
    free(adj);

    return 0;
}
