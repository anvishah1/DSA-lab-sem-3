#include <stdio.h>
#include <stdbool.h>
#include <limits.h>

int n;
int totalweight=0;

int minindex(int dist[], bool mst[]) {
    int min = INT_MAX;
    int index=-1;
    for (int i = 0; i < n; i++) {
        if (!mst[i] && dist[i] < min) {
            min = dist[i];
            index = i;
        }
    }
    return index;
}


void TotalWeight() {
    printf("%d\n", totalweight);
}


void primsmst(int src, int graph[n][n], int parent[]) {
    int dist[n];
    bool mst[n];


    for (int i = 0; i < n; i++) {
        dist[i] = INT_MAX;
        mst[i] = false;
        parent[i]=-1;
    }

    dist[src] = 0;  

    for (int i = 0; i < n - 1; i++) {
        int u = minindex(dist, mst);  
        mst[u] = true;

    if(parent[u]!=-1){ 
        printf("%d %d (%d) ", parent[u], u, graph[u][parent[u]]);
    }

        for (int v = 0; v < n; v++) {
            if (!mst[v] && graph[u][v]!=0 && graph[u][v]!=INT_MAX && dist[v] > graph[u][v]) {
                parent[v] = u;
                dist[v] = graph[u][v];
            }
        }
    }
  int lnode= minindex(dist,mst);
    if(lnode !=-1 && parent[lnode]!=-1){
        printf("%d %d (%d) ",parent[lnode],lnode,graph[lnode][parent[lnode]]);
    }
    for (int i = 0; i < n; i++) {
    if(parent[i]!= -1){
        totalweight += graph[i][parent[i]];
    }
    }
}

int main() {
    scanf("%d", &n);  
    int graph[n][n];

    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            scanf("%d", &graph[i][j]);
            if(graph[i][j]== 0 && i!=j)
                graph[i][j]= INT_MAX;
        }
    }

    int parent[n];  
    char c;
    int src;


    do {
        scanf(" %c", &c);
        switch (c) {
            case 's': 
                scanf("%d", &src);
                primsmst(src, graph, parent);
                printf("\n");
                break;
            case 'b':  
                TotalWeight(parent, graph);
                
                break;
            case 'e': 
                break;
            default:
                break;
        }
    } while (c != 'e');
    return 0;
}
