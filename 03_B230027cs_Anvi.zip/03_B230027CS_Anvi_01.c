#include <stdio.h>
#include <string.h>
#include <stdlib.h>

struct stud{
    char name[100];
    char rollno[10];
    int age;
    int index;
};

 void groupindex(struct stud s[],int n){
    for(int j=0; j<n; j++){
    int sum=0;
    for(int i=0; i<strlen(s[j].name); i++){
        sum = sum +(s[j].name[i]);
    }
    s[j].index=(sum + s[j].age) % 4;
    }
 }
 void printgroupindex(struct stud s){
     printf("%d\n",s.index);
 }
 
int collect(struct stud s[],int k,int n){
    char *collect[100];
    int count=0;
    for(int i=0;i<n;i++){
        if(s[i].index==k){
            collect[count++]=s[i].name;
    }
    }
    for(int i=0;i<count-1;i++){
        for(int j=i+1;j<count;j++){
            if(strcmp(collect[i],collect[j])>0){
                char *temp=collect[i];
                collect[i]=collect[j];
                collect[j]=temp;
            }
        }
    }
    if(count==0){
        return 0;
    }
    printf("%d ",count);
    for(int i=0;i<count;i++){
        printf("%s ",collect[i]);
    }
    printf("\n");
}

 int studentdetail(struct stud s[],char c[],int n){
    for(int i=0; i< n; i++){
        if(strcmp(c,s[i].rollno)==0){
            printf("%s %d %c%c\n",s[i].name,s[i].age,s[i].rollno[7],s[i].rollno[8]);
            return 0;
        }
    }
    return 1;
}

int grouplist(struct stud s[],int n,int k,char c[3]){

    for(int i=0;i<n;i++){
        if(s[i].index==k){
            if((s[i].rollno[7]==c[0] || (s[i].rollno[7]+32)==c[0]) && (s[i].rollno[8]==c[1] || s[i].rollno[8] +32 ==c[1])){
                printf("%s ",s[i].name);
                return 0;
            }  
        }
    }
    return 1;

}

int transfer(struct stud s[],int u,int l,char c[3],int n){
    int count=0;
    for(int i=0; i < n ;i++){
        if(s[i].index==u && ((s[i].rollno[7]==c[0] || s[i].rollno[7] + 32 ==c[0]) && (s[i].rollno[8]==c[1] || s[i].rollno[8] +32==c[1]))){
            s[i].index= l;
            count=count+1;
        }
    }
    return count;
}


 int main(){
 int n;
 char c;
 int x;
 int o;
 int u,l;
 char ch[3];
 char str[100];
 scanf("%d",&n);
 struct stud s[n];

for(int i=0;i<n;i++){
    scanf("%s %s %d",s[i].name,s[i].rollno,&s[i].age);
}
    groupindex(s,n);
do{
    scanf(" %c",&c);
    switch(c){

    case 'a':
    scanf("%s",str);
    for(int i=0;i<n;i++){
    if(!strcmp(str,s[i].name)){
        printgroupindex(s[i]);
    }}
    break;

    case 'b':
    scanf("%d",&x);
    o = collect(s,x,n);
    if(o==0){
        printf("-1\n");
    }
    break;

    case 'c':
    scanf("%d %s",&x,ch);
    o=grouplist(s,n,x,ch);
    if(o==1)
        printf("-1");
    printf("\n");
    break;
 
    case 'd':
    scanf("%s",str);
    x=studentdetail(s,str,n);
    if(x==1)
    printf("-1\n");
    break;

    case 'e':
    scanf("%d %d %s",&u,&l,ch);
    x=transfer(s,u,l,ch,n);
    printf("%d\n",x);
    break;

    case 'f':
    break;
}
    }while(c!='f');

}

