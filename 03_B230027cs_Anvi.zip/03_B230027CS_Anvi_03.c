#include <stdio.h>
#include <stdlib.h>

int hash1(int key,int n){
    int index=key % n;
    return index;
}

int hash2(int key,int n){
    int flag=0;
    int prime;
    for(int i=n-1;i >=2;i--){
        flag=0;
        for(int j=2;j<i;j++){
            if(i%j==0)
                flag=1;
        }
        if(flag==0){
        prime=i;
        break;
        }
    }
    int index = prime-(key % prime);
    return index;
}

int lp(int a2[],int m,int n,int a[]){
    int count=0;
    for(int i=0;i<m;i++){
        int index=hash1(a2[i],n);
        int j=0;
        while(a[index]!=-1){
        index=(hash1(a2[i],n) + (++j)) %n;
        count=count+1;
    }
        a[index]=a2[i];
        printf("%d ",index);
    }

    return count;
    }

int qp(int a2[],int m,int n,int a[]){
        int count=0;
    for(int i=0; i<m; i++){
        int index=hash1(a2[i],n);
        int j=1;
            while(a[index]!=-1){
            int k=j*j;
            index=(hash1(a2[i],n) + k) % n;
            count=count+1;
            j++;
    }
            a[index]=a2[i];
            printf("%d ",index);
    }
   return count;
    }
    
int dh(int a2[],int m,int n,int a[]){
        int count=0;
    for(int i=0; i<m; i++){
        int index=hash1(a2[i],n);
        int j=1;
            while(a[index]!=-1){
            index =(hash1(a2[i],n) + j *hash2(a2[i],n)) % n;
            count=count+1;
            j++;
    }
            a[index]=a2[i];
            printf("%d ",index);
    }
   return count;
    }

int main(){
int n;
int m;
int x;
scanf("%d %d",&n,&m);
int lp1[n];
for(int i=0; i< n;i++){
    lp1[i]=-1;
}
int qp1[n];
for(int i=0; i< n;i++){
    qp1[i]=-1;
}
int dh1[n];
for(int i=0; i< n;i++){
    dh1[i]=-1;
}
int a2[m];
for(int i=0;i<m;i++){
    scanf("%d",&a2[i]);
}
char c;
do{
    scanf(" %c",&c);
    switch(c){
        case 'a':
        x=lp(a2,m,n,lp1);
        printf("\n");
        printf("%d\n",x);
        break;

        case 'b':
        x=qp(a2,m,n,qp1);
        printf("\n");
        printf("%d\n",x);
        break;
        
        case 'c':
        x=dh(a2,m,n,dh1);
        printf("\n");
        printf("%d\n",x);
        break;

        case 'd':
        break;
    }
}while(c!='d');
}
