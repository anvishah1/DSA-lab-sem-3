#include <stdio.h>
#include <stdlib.h>

struct node {
    int key;
    struct node *next;
};

int hashfunction(int key,int n){
    int index=key % n;
    return index;
}

struct node *createnode(int key){
    struct node *newnode=(struct node *)malloc(sizeof(struct node));
    newnode->key=key;
    newnode->next=NULL;
    return newnode;
}

void insertnode(int key,int n,struct node *ht[]){
    int index=hashfunction(key,n);
    struct node *temp =ht[index];
    struct node * prev=NULL;
    struct node *newnode=createnode(key);

    while(temp!=NULL && temp->key < key){
         prev=temp;
        temp=temp->next;
    }
    if(temp!=NULL && temp->key==key){
        printf("-1\n");
        free(newnode);
    }
    if(prev==NULL){
        newnode->next=ht[index];
        ht[index]=newnode;
    }
    else{
        prev->next=newnode;
        newnode->next=temp;
    }
}

void search(struct node *ht[],int key,int n){
    int index=hashfunction(key,n);
    int pos=1;
    struct node *temp=ht[index];
    while(temp!=NULL && temp->key!=key){
        pos=pos+1;
        temp=temp->next;
    }
    if(temp!=NULL && temp->key==key){
        printf("%d %d\n",index,pos);
    }
    else{
        printf("-1\n");
    }
}

void deletenode(struct node *ht[],int key,int n){
    int index= hashfunction(key,n);
    int pos=1;
    struct node *temp=ht[index];
    struct node *prev=NULL;

    while(temp!=NULL && temp->key!=key){
        pos=pos+1;
        prev=temp;
        temp=temp->next;
    }
    if(temp==NULL){
        printf("-1\n");
    }

    if(temp!=NULL && temp->key==key){
        if(prev==NULL){
            ht[index]=temp->next;
    }
    else{
        prev->next=temp->next;
    }
    printf("%d %d\n",index,pos);
    free(temp);
}
}


void update(struct node *ht[], int oldi,int newi,int n){
    int index=hashfunction(oldi,n);
    struct node *temp1=ht[index];
    struct node *temp2=ht[index];
    while(temp1!=NULL){
        if(temp1->key == newi){
            printf("-1\n");
            return;
        }
        temp1=temp1->next;
    }

    while(temp2!=NULL){
        if(temp2->key==oldi){
            deletenode(ht,oldi,n);
            insertnode(newi,n,ht);
            return;
        }
        temp2=temp2->next;
    }

    printf("-1\n");

}

void printele(struct node *ht[],int ind){
    struct node *temp=ht[ind];
    while(temp!=NULL){
        printf("%d ",temp->key);
        temp=temp->next;
    }
}

int main(){
    int n;
    scanf("%d",&n);
    struct node *ht[n];
    for(int i=0;i <n; i ++){
        ht[i]=NULL;
    
    }
    char c;
    int k;
    int oldi,newi;
    do{
        scanf(" %c",&c);
        switch(c){
            case 'a':
            scanf("%d",&k);
            insertnode(k,n,ht);
            break;

            case 'b':
            scanf("%d",&k);
            search(ht,k,n);
            break;

            case 'c':
            scanf("%d",&k);
            deletenode(ht,k,n);
            break;
            
            case 'd':
            scanf("%d %d",&oldi,&newi);
            update(ht,oldi,newi,n);
            break;

            case 'e':
            scanf("%d",&k);
            printele(ht,k);
            printf("\n");
            break;

            case 'f':
            break;


        }
    }while(c!='f');
}
