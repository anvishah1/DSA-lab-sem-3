#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct node{
    int key;
    char name[50];
    int price;
    struct node *left;
    struct node *right;
    struct node *p;
};

struct node *create_node(int val,int price,char name[]){
    struct node *newnode=(struct node *)malloc(sizeof(struct node));
    newnode->key=val;
    newnode->price=price;
    strcpy(newnode->name,name);
    newnode->left=NULL;
    newnode->right=NULL;
    newnode->p=NULL;
    return newnode;
}

struct node *add_node(struct node *root,int val,int price,char name[]){
    struct node *newnode=create_node(val,price,name);
    struct node *temp=root;
    struct node *prev=NULL;
    if(root==NULL){
        root=newnode;
        newnode->p=NULL;
    }
    else{
        while(temp!=NULL){
        if(temp->key > newnode->key){
            prev=temp;
            temp=temp->left;
        }
        else{
            prev=temp;
            temp=temp->right;
        }
    }
    if(prev->key > newnode->key){
        prev->left=newnode;
        newnode->p=prev;}
    else{
    prev->right=newnode;
    newnode->p=prev;}
    }
    return root;
}

struct node *searchnode(struct node *root,int val){
    struct node *temp=root;
    if(temp==NULL || temp->key==val)
        return temp;
        if(temp->key>val){
            searchnode(temp->left,val);
        }
        else{
            searchnode(temp->right,val);
    }
}

void inorder(struct node *root){
    if(root==NULL)
        return;
    inorder(root->left);
    printf("%d %s %d\n",root->key,root->name,root->price);
    inorder(root->right);
}

void preorder(struct node *root){
    if(root==NULL)
        return;
    printf("%d %s %d\n",root->key,root->name,root->price);
    preorder(root->left);
    preorder(root->right);
}

void postorder(struct node *root){
    if(root==NULL)
        return;
    postorder(root->left);
    postorder(root->right);
    printf("%d %s %d\n",root->key,root->name,root->price);
}

struct node *modify(struct node *root, int val, int price){
    struct node *temp=root;
    while(temp!=NULL && temp->key!=val){
        if(temp->key > val)
            temp=temp->left;
        else
            temp=temp->right;
        
    }
    if(temp!=NULL && temp->key==val){
        temp->price=price;
    }
    return temp;
}

struct node *successor(struct node *node){
    node=node->right;
    while(node !=NULL && node->left!=NULL){
        node=node->left;
    }
    return node;
}
/*node transplant(node root, node subroot1, node subroot2) {
    if (subroot1->par == NULL) root = subroot2;
    else if (subroot1 == subroot1->par->left) subroot1->par->left = subroot2;
    else subroot1->par->right = subroot2;
    if (subroot2 != NULL) subroot2->par = subroot1->par;
    return root;
}

node Delete(node root, int n) {
    node t = search(root, n);
    if (root == NULL || t == NULL) {
        printf("-1\n");
        return root;
    }
    if (t->left == NULL) root = transplant(root, t, t->right);
    else if (t->right == NULL) root = transplant(root, t, t->left);
    else {
        node x = min(t->right);
        if (x->par != t) {
            root = transplant(root, x, x->right);
            x->right = t->right;
            x->right->par = x;
        }
        root = transplant(root, t, x);
        x->left = t->left;
        x->left->par = x;
    }
    printf("%d %s %d\n", t->mnum, t->mname, t->price);
    free(t);
    return root;
}
*/
struct node *deleteNode(struct node *root, int key) {
    if (root == NULL){
        printf("-1\n");
        return root;
}
    if (key < root->key)
        root->left = deleteNode(root->left, key);
    else if (key > root->key)
        root->right = deleteNode(root->right, key);
    else {
        printf("%d %s %d\n",
               root->key, root->name, root->price);

        if (root->left == NULL) {
            struct node *temp = root->right;
            free(root);
            return temp;
        } else if (root->right == NULL) {
            struct node *temp = root->left;
            free(root);
            return temp;
        }

        struct node *temp = successor(root->right);

        root->key = temp->key;
        root->price = temp->price;
        strcpy(root->name, temp->name);

        root->right = deleteNode(root->right, temp->key);
    }

    return root;
}

int main(){
    struct node *root=NULL;
    struct node *x=NULL;
    char c;
    int val;
    int price;
    char name[50];
    do{
        scanf(" %c",&c);
        switch(c){
            case 'a':
            scanf("%d %s %d",&val,name,&price);
            root=add_node(root,val,price,name);
            break;

            case 's':
            scanf("%d",&val);
            x=searchnode(root,val);
            if(x!=NULL)
                printf("%d %s %d\n",x->key,x->name,x->price);
            else
                printf("-1\n");
            break;

            case 'i':
            inorder(root);
            break;

            case 'p':
            preorder(root);
            break;

            case 't':
            postorder(root);
            break;

            case 'm':
            scanf("%d %d",&val,&price);
            x=modify(root,val,price);
            if(x!=NULL)
                printf("%d %s %d\n",x->key, x->name, x->price);
            else
                printf("-1\n");
            break;

            case 'd':
            scanf("%d",&val);
            root=deleteNode(root,val);
            break;

            case 'e':
            break;

    }
        }while(c!='e');

}