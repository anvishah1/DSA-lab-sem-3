#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct patient{
    int id;
    char name[20];
    int s;//severity level
};

void swap(struct patient p[],int min, int key){

    int temp1=p[min].id;
    p[min].id=p[key].id;
    p[key].id=temp1;

    char temp2[20];
    strcpy(temp2,p[min].name);
    strcpy(p[min].name,p[key].name);
    strcpy(p[key].name,temp2);

    int temp3=p[min].s;
    p[min].s=p[key].s;
    p[key].s=temp3;
}

void heapify(struct patient p[],int key, int len){
    int min=key;
    int l=2*key +1;
    int r=2*key +2;
    if(l < len && p[l].s < p[min].s)
        min=l;
    if( r < len && p[r].s < p[min].s)
        min =r;
    if(min!=key){
        swap(p,min,key);
        heapify(p,min,len);
    }
    
}
void admit(int key,char name[],int s, struct patient p[],int *n){

    p[*n].id=key;
    strcpy(p[*n].name,name);
    p[*n].s=s;
     *n=*n+1;

   for(int i=(*n)/2-1; i >=0; i--){
    heapify(p,i,*n);
   }

   for(int i=0;i<(*n);i++){
    printf("%d ",p[i].id);
   }
   printf("\n");
}

void treatpatient(struct patient p[],int *n){
    if (*n==0){
        printf("-1\n");
        return;
    }
    swap(p,0,(*n-1));
    printf("%d %s\n",p[*n-1].id,p[*n-1].name);
    *n=(*n)-1;
    heapify(p,0,*n);

}
 void updatesev(struct patient p[],int key,int new,int n){
    int flag=0;
    int x;
    for(int i=0; i < n; i++){
        if(p[i].s==new){
            printf("-1\n");
            return;
        }}
        for(int i=0; i < n; i++){
        if(p[i].id==key){
            flag=1;
            x=i;
            break;
        }
        }
    if(flag==0){
        printf("-1\n");
        return;
    }
    else{
        p[x].s=new;
        for(int i=n/2-1; i>=0; i--){
            heapify(p,i,n);
        }
    }
    for(int i=0; i < n; i++){
    printf("%d ",p[i].id);
    }
    printf("\n");
 }

void querypatient(struct patient p[],int key,int n){
    int flag=0;
    for(int i=0; i< n;i ++){
        if(p[i].id==key){
            flag=1;
            printf("%s %d\n",p[i].name,p[i].s);
            return;
        }
    }
    if(flag==0){
        printf("-1\n");
    }
}

void findmostsevere(struct patient p[],int n){
    if(n==0){
        printf("-1\n");
        return;
    }
    int x;
    if(n < 3){
        x=n;
    }
    else{
        x=3;
    }
    if(n==0){
        printf("-1\n");
        return;
    }
    struct patient b[x];
    for(int i=0; i < x; i++){
            b[i]=p[i];
        }
    for(int i=0; i<x-1;i++){
        int min=i;
        for(int j=i+1;j< x ;j++){
            if(b[j].s < b[min].s)
            min=j;
        }
        swap(b,i,min);
    }

    for(int i=0 ;i < x; i++){
        printf("%d %s %d\n",b[i].id,b[i].name,b[i].s);
    }
}

int main(){
int n=0;
struct patient p[100];
char c;
int key;
char name[20];
int s;
do{
    scanf(" %c",&c);
    switch(c){

        case 'a':
        scanf("%d %d %s",&key,&s,name);
        admit(key,name,s,p,&n);
        break;

        case 'b':
        treatpatient(p,&n);
        break;

        case 'c':
        scanf("%d %d",&key,&s);
        updatesev(p,key,s,n);
        break;

        case 'd':
        scanf("%d",&key);
        querypatient(p,key,n);
        break;

        case 'e':
        findmostsevere(p,n);
        break;
    }
}while(c!='g');
}