#include <stdio.h>
#include <stdlib.h>

void heapify(int a[],int n,int len){
    int max=n;
    int l=2*n+1;
    int r=2*n+2;
    if(l<len && a[max] < a[l])
        max=l;
    if(r<len && a[max] < a[r])
        max=r;
    if(max!=n){
    int temp=a[max];
    a[max]=a[n];
    a[n]=temp;
    heapify(a,max,len);
    }
    }

void insert(int arr[],int *n,int key){
    for(int i=0;i<*n;i++){
        if(arr[i]==key){
            return;
        }
    }
    *n=*n+1;
    arr[*n-1]=key;
    for(int i=(*n)/2-1;i>=0;i--){
        heapify(arr,i,*n);
    }
}

void findmax(int arr[],int n){
    if(n==0){
        printf("-1\n");
        return;
    }
    printf("%d\n",arr[0]);
}

void extract_max(int arr[],int *n){
    if(*n==0){
        printf("-1\n");
        return;
    }
    int temp=arr[0];
    arr[0]=arr[*n-1];
    arr[*n-1]=temp;
    printf("%d ",arr[*n-1]);
    *n=*n-1;

    heapify(arr,0,*n);
    for(int i=0; i<*n;i++){
        printf("%d ",arr[i]);
    }
    printf("\n");

}

void deletekey(int arr[],int *n,int key){
    int x;
    int flag=0;
    for(int i=0;i<*n;i++){
        if(arr[i]==key){
            flag=1;
            x=i;
        }
    }
    if(flag==0){
        printf("-1\n");
        return;
    }
    else if(flag==1 && *n==1){
        *n=0;
        printf("0\n");
        return;
    }
    else{
        int temp=arr[*n-1];
        arr[*n-1]=arr[x];
        arr[x]=temp;
        *n=*n-1;
        heapify(arr,0,*n);

        for(int i=0; i<*n;i++){
            printf("%d ",arr[i]);
        }
        printf("\n");
    }
}

void kthlargest(int b[],int k,int n){
    if(k >n){
        printf("-1\n");
        return;
    }
    int a[n];
    for(int i=0;i<n;i++){
        a[i]=b[i];
    }
    for(int i=0;i<n-1;i++){
        int max=i;
        for(int j=i+1;j<n;j++){
            if(a[j]> a[max])
                max=j;
            }
        if(max!=i){
            int temp=a[max];
            a[max]=a[i];
            a[i]=temp;
        }
        }
        printf("%d\n",a[k-1]);
    }


void replace_key(int arr[],int old,int new,int n){
    int flag=0;
    int x;
    for(int i=0;i<n;i++){
        if(arr[i]==old){
            flag=1;
            x=i;
            break;
        }
    }
    if(flag==0){
        int diff=abs(old-new);
        printf("%d\n",diff);
        return;
    }
    else{
        arr[x]=new;
            for(int i=(n/2)-1;i>=0;i--){
            heapify(arr,i,n);
            }
        for(int i=0;i<n;i++){
            printf("%d ",arr[i]);
        }
        printf("\n");
    }

}

int main(){
    int n=0;
    int arr[100];
    int key;
    int old;
    int new;
    char c;
    do{
        scanf(" %c",&c);
        switch(c){
            case 'a':
            scanf("%d",&key);
            insert(arr,&n,key);
            break;

            case 'b':
            findmax(arr,n);
            break;

            case 'c':
            extract_max(arr,&n);
            break;

            case 'd':
            scanf("%d",&key);
            kthlargest(arr,key,n);
            break;

            case 'e':
            scanf("%d",&key);
            deletekey(arr,&n,key);
            break;

            case 'f':
            scanf("%d %d",&old,&new);
            replace_key(arr,old,new,n);
            break;

            case 'g':
            break;
        }
    }while(c!='g');

}
