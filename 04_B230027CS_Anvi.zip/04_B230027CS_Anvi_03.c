#include <stdio.h>
#include <stdlib.h>

struct job{
    int id;
    int p;
};

void swap(struct job j[],int a,int b){
    int temp1=j[a].id;
    j[a].id=j[b].id;
    j[b].id=temp1;

    int temp2=j[a].p;
    j[a].p=j[b].p;
    j[b].p=temp2;
}

void heapify(struct job j[],int k,int n){
    int min=k;
    int l=2*k+1;
    int r=2*k+2;
    if(l < n && j[l].p < j[min].p)
        min=l;
    if(r < n && j[r].p < j[min].p)
        min=r;
    if(min!=k){
        swap(j,min,k);
        heapify(j,min,n);
    }
}

void add(struct job j[],int k,int p,int *n){
    j[*n].id=k;
    j[*n].p=p;
    *n=*n+1;

    for(int i=(*n)/2-1;i >=0; i--){
            heapify(j,i,*n);
    }

}

void schedule(struct job j[],int *n){
    if(*n==0){
        printf("-1\n");
        return;
    }
    swap(j,0,*n-1);
    printf("%d\n",j[*n-1].id);
    *n=*n-1;
    heapify(j,0,*n);
}

void next_job(struct job j[],int n){
    if(n==0){
        printf("-1\n");
        return;
    }
    printf("%d\n",j[0].id);
}

void replacepriority(struct job j[],int id,int np,int n){
    int flag=0;
    int x;
    for(int i=0;i<n;i++){
        if(j[i].id==id){
            flag=1;
            x=i;
        }
    }
    if(flag==0){
        printf("-1\n");
        return;
    }
    else{
        j[x].p=np;
        for(int i=n/2-1;i >=0;i--){
            heapify(j,i,n);
        }
    }
}

void display(struct job j[],int n){
    if(n==0){
        printf("-1\n");
        return;
    }
    for(int i=0;i <n; i++){
        printf("%d %d\n",j[i].id,j[i].p);
    }
}

int main(){
    int n=0;
    struct job j[11];
    char c;
    int p;
    int np;
    int id;
    do{
        scanf(" %c",&c);
        switch(c){
            case 'a':
            scanf("%d %d",&id,&p);
            add(j,id,p,&n);
            break;

            case 'b':
            schedule(j,&n);
            break;

            case 'c':
            next_job(j,n);
            break;

            case 'd':
            scanf("%d %d",&id,&np);
            replacepriority(j,id,np,n);
            break;

            case 'e':
            display(j,n);
            break;

            case 'g':
            break;
        }
    }while(c!='g');
}