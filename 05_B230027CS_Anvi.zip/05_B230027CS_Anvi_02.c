#include <stdio.h>
#include <stdbool.h>
#define MAX 100

bool bfscycle(int G[MAX][MAX], int n, int src, bool visited[], int parent[]) {
    int q[MAX];
    int r = 0;
    int f = 0;
    q[r++] = src;
    visited[src] = true;
    parent[src] = -1;
    while (f < r) {
        int u = q[f++];
        for (int v = 0; v < n; v++) {
            if (G[u][v] && !visited[v]) {
                visited[v] = true;
                parent[v] = u;
                q[r++] = v;
            }
            else if (G[u][v] && v != parent[u]) {
                return true;  
            }
        }
    }
    return false;
}

void hascycle(int G[MAX][MAX], int n) {
    bool visited[MAX];
    int parent[MAX];

    for (int i = 0; i < n; i++) {
        visited[i] = false;
        parent[i] = -1;
    }

    for (int i = 0; i < n; i++) {
        if (!visited[i]) {
            if (bfscycle(G, n, i, visited, parent)) {
                printf("1\n");
                return;
            }
        }
    }
    printf("-1\n");
}

bool bfsbipartite(int G[MAX][MAX], int n, int src, int check[]) {
    int q[MAX];
    int f = 0;
    int r = 0;  
    q[r++] = src;
    check[src] = 1;  
    while (f < r) {
        int u = q[f++];
        for (int v = 0; v < n; v++) {
            if (G[u][v] && check[v] == -1) {  
                check[v] = 1 - check[u];  
                q[r++] = v;
            } else if (G[u][v] && check[v] == check[u]) {  
                return false;  
            }
        }
    }
    return true;
}
void isbipartite(int G[MAX][MAX], int n) {
    int check[MAX];
    for (int i = 0; i < n; i++) {
        check[i] = -1; 
    }
    for (int i = 0; i < n; i++) {
        if (check[i] == -1) { 
            if (!bfsbipartite(G, n, i, check)) {
                printf("-1\n");
                return;
            }
        }
    }
    printf("1\n");
}


void istree(int G[MAX][MAX], int n) {
    int edgecount = 0;
    for (int i = 0; i < n; i++) {
        for (int j = i + 1; j < n; j++) {
            if (G[i][j]) 
                edgecount++;
        }
    }
    if (edgecount != n - 1) {
        printf("-1\n");
        return;
    }
    bool visited[MAX];
    int parent[MAX];
    for (int i = 0; i < n; i++) {
        visited[i] = false;
        parent[i] = -1;
    }
    if (bfscycle(G, n, 0, visited, parent)) {
        printf("-1\n");
        return;
    }
    for (int i = 0; i < n; i++) {
        if (!visited[i]) {
            printf("-1\n");
            return;
        }
    }
    printf("1\n");
}

int main() {
    int n;
    int G[MAX][MAX];

    scanf("%d", &n);
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            scanf("%d", &G[i][j]);
        }
    }
    char c;
    do{
        scanf(" %c", &c);
        switch (c) {
            case 'a':
                isbipartite(G, n);
                break;
            case 'b':
                hascycle(G, n);
                break;
            case 'c':
                istree(G, n);
                break;
            case 'x':
                break;
        }
    }while(c!='x');
}
