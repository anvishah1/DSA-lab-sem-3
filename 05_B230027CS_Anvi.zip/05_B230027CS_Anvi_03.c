#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#define MAX 1000  


typedef struct Graph {
    int V;             
    int **adj;         
} Graph;


Graph* creategraph(int V);
void addedge(Graph *graph, int u, int v);
bool iscyclicutil(Graph *graph, int v, bool *visited, bool *recStack);
bool isdag(Graph *graph);
void DFS(Graph *graph, int v, bool *visited);
void transposegraph(Graph *graph, Graph *transpose);
void fillorder(Graph *graph, int v, bool *visited, int *stack, int *top);
void countsccutil(Graph *transpose, int v, bool *visited);
int countsconnectedcomp(Graph *graph);
void fgraph(Graph *graph);


Graph* creategraph(int V) {
    Graph *graph = (Graph *)malloc(sizeof(Graph));
    graph->V = V;
    graph->adj = (int **)malloc(V * sizeof(int *));
    for (int i = 0; i < V; i++) {
        graph->adj[i] = (int *)calloc(V, sizeof(int));  
    }
    return graph;
}

void addedge(Graph *graph, int u, int v) {
    if (u >= 0 && u < graph->V && v >= 0 && v < graph->V) {  
        graph->adj[u][v] = 1;
    }
}

void fillorder(Graph *graph, int v, bool *visited, int *stack, int *top) {
    visited[v] = true;
    
    for (int i = 0; i < graph->V; i++) {
        if (graph->adj[v][i] && !visited[i]) {
            fillorder(graph, i, visited, stack, top);
        }
    }
    stack[++(*top)] = v;
}

bool iscyclicutil(Graph *graph, int v, bool *visited, bool *recstack) {
    if (!visited[v]) {
        visited[v] = true;
        recstack[v] = true;

        for (int i = 0; i < graph->V; i++) {
            if (graph->adj[v][i]) {
                if (!visited[i] && iscyclicutil(graph, i, visited, recstack)) {
                    return true;
                } else if (recstack[i]) {
                    return true;
                }
            }
        }
    }
    recstack[v] = false;
    return false;
}

bool isdag(Graph *graph) {
    bool *visited = (bool *)calloc(graph->V, sizeof(bool));
    bool *recstack = (bool *)calloc(graph->V, sizeof(bool));
    
    for (int i = 0; i < graph->V; i++) {
        if (iscyclicutil(graph, i, visited, recstack)) {
            free(visited);
            free(recstack);
            return false;
        }
    }
    
    free(visited);
    free(recstack);
    return true;
}

void transposegraph(Graph *graph, Graph *transpose) {
    for (int i = 0; i < graph->V; i++) {
        for (int j = 0; j < graph->V; j++) {
            if (graph->adj[i][j]) {
                addedge(transpose, j, i);
            }
        }
    }
}


void countsccutil(Graph *transpose, int v, bool *visited) {
    visited[v] = true;
    
    for (int i = 0; i < transpose->V; i++) {
        if (transpose->adj[v][i] && !visited[i]) {
            countsccutil(transpose, i, visited);
        }
    }
}


int countsconnectedcomp(Graph *graph) {
    int *stack = (int *)malloc(graph->V * sizeof(int));
    int top = -1;
    bool *visited = (bool *)calloc(graph->V, sizeof(bool));
    
    for (int i = 0; i < graph->V; i++) {
        if (!visited[i]) {
            fillorder(graph, i, visited, stack, &top);
        }
    }
    

    Graph *transpose = creategraph(graph->V);
    transposegraph(graph, transpose);
    

    for (int i = 0; i < graph->V; i++) {
        visited[i] = false;
    }
    

    int count = 0;
    while (top != -1) {
        int v = stack[top--];
        if (!visited[v]) {
            countsccutil(transpose, v, visited);
            count++;
        }
    }
    
    free(stack);
    free(visited);
    fgraph(transpose);
    
    return count;
}


void fgraph(Graph *graph) {
    for (int i = 0; i < graph->V; i++) {
        free(graph->adj[i]);
    }
    free(graph->adj);
    free(graph);
}


int main() {
    int n, m;
    scanf("%d %d",&n, &m);
    
    Graph *graph = creategraph(n);
    
    for (int i = 0; i < m; i++) {
        int u, v;
        scanf("%d %d", &u, &v);
        addedge(graph, u, v);
    }
    
    char c;
    while (scanf(" %c", &c) != EOF) {
        if (c == 'a') {
            if (isdag(graph)) {
                printf("1\n"); 
            } else {
                printf("-1\n");  
            }
        } else if (c == 'b') {
            int scccount = countsconnectedcomp(graph);
            printf("%d\n", scccount);
        } else if (c == 'x') {
            break;
        }
    }
    
    fgraph(graph);
}
