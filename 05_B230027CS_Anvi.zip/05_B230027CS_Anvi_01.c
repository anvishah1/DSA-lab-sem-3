#include <stdio.h>
#include <stdbool.h>
#define MAX 100

int n; 
int adj[MAX][MAX]; 
bool visited[MAX];
int timein[MAX], l[MAX], parent[MAX];
bool art_point[MAX];

void DFS(int v) {
    visited[v] = true;
    for (int u = 0; u < n; u++) {
        if (adj[v][u] && !visited[u]) {
            DFS(u);
        }
    }
}
void initializeParent() {
    for (int i = 0; i < n; i++) {
        parent[i] = -1;
    }
}
void initializeVisited() {
    for (int i = 0; i < n; i++) {
        visited[i] = false;
    }
}
void initializeArticulationPoint() {
    for (int i = 0; i < n; i++) {
        art_point[i] = false;
    }
}


int noOfConnectedComp() {
    int count = 0;
    initializeVisited();
    for (int i = 0; i < n; i++) {
        if (!visited[i]) {
            DFS(i);
            count++;
        }
    }
    return count;
}


int DFSCompsize(int v) {
    visited[v] = true;
    int size = 1; 
    for (int u = 0; u < n; u++) {
        if (adj[v][u] && !visited[u]) {
            size += DFSCompsize(u);
        }
    }
    return size;
}
void sizeOfComp() {
    initializeVisited();
    int sizecount = 0;
    int compsizes[MAX];
    for (int i = 0; i < n; i++) {
        if (!visited[i]) {
            int size = DFSCompsize(i);
            compsizes[sizecount++] = size;
        }
    }
    for (int i = 0; i < sizecount - 1; i++) {
        for (int j = 0; j < sizecount - i - 1; j++) {
            if (compsizes[j] > compsizes[j + 1]) {
                int temp = compsizes[j];
                compsizes[j] = compsizes[j + 1];
                compsizes[j + 1] = temp;
            }
        }
    }
    for (int i = 0; i < sizecount; i++) {
        printf("%d ", compsizes[i]);
    }
    printf("\n");
}


void DFSbridges(int v, int* timer, int* bridgeno) {
    visited[v] = true;
    timein[v] = l[v] = (*timer)++;
    
    for (int u = 0; u < n; u++) {
        if (adj[v][u]) {
            if (!visited[u]) {
                parent[u] = v;
                DFSbridges(u, timer, bridgeno);
                l[v] = (l[u] < l[v]) ? l[u] : l[v];
                if (l[u] > timein[v]) {
                    (*bridgeno)++;
                }
            } else if (u != parent[v]) {
                l[v] = (timein[u] < l[v]) ? timein[u] : l[v];
            }
        }
    }
}
int noOfBridges() {
    initializeVisited();
    initializeParent();
    int bridgeno = 0;
    int timer = 0;
    for (int i = 0; i < n; i++) {
        if (!visited[i]) {
            DFSbridges(i, &timer, &bridgeno);
        }
    }
    return bridgeno;
}


void DFS_art_point(int v, int* timer, int* rootch) {
    visited[v] = true;
    timein[v] = l[v] = (*timer)++;
         for (int u = 0; u < n; u++) {
        if (adj[v][u]) {
            if (!visited[u]) {
                parent[u] = v;
                if (parent[v] == -1) (*rootch)++; 

                DFS_art_point(u, timer, rootch);
                
                l[v] = (l[u] < l[v]) ? l[u] : l[v];

                if (l[u] >= timein[v] && parent[v] != -1) {
                    art_point[v] = true;
                }
            } else if (u != parent[v]) {
                l[v] = (timein[u] < l[v]) ? timein[u] : l[v];
            }
        }
    }
}
int noofartpoints() {
    initializeVisited();
    initializeParent();
    initializeArticulationPoint();
    int timer = 0;
    int artcount = 0;

    for (int i = 0; i < n; i++) {
        if (!visited[i]) {
            int rootch = 0;
            DFS_art_point(i, &timer, &rootch);
            if (rootch > 1) 
                art_point[i] = true;
        }
    }
    for (int i = 0; i < n; i++) {
        if (art_point[i]) 
            artcount++;
    }
    return artcount;
}


int main() {
    scanf("%d", &n);
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            scanf("%d", &adj[i][j]);
        }
    }
    char i;
    do {
        scanf(" %c", &i);
        switch (i) {
            case 'a':
                printf("%d\n", noOfConnectedComp());
                break;
            case 'b':
                sizeOfComp();
                break;
            case 'c':
                printf("%d\n", noOfBridges());
                break;
            case 'd':
            printf("%d\n",noofartpoints());
                break;
            case 'x':
                break;
        }
    } while (i!= 'x');
}
