#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

int n;

void display(int dist[n][n],int n){
    for(int i=0; i < n; i++){
        for(int j=0;j < n;j++){
            if(dist[i][j] == INT_MAX)
                printf("INF ");
            else
                printf("%d ",dist[i][j]);
        }
            printf("\n");
    }

}

void floydwarshall(int dist[n][n],int n){
    for(int k=0; k < n; k++){
        for(int i=0 ; i < n;i++){
            for(int j=0; j <n; j++){
                if(dist[i][k] != INT_MAX && dist[k][j]!=INT_MAX && dist[i][j]> dist[i][k] + dist[k][j])
                    dist[i][j]=dist[i][k]+dist[k][j];
            }
        }
    }

    display(dist,n);
}

int main(){
    scanf("%d",&n);
    int graph[n][n];
    for(int i=0; i< n; i++){
        for(int j=0; j < n; j++){
            scanf("%d",&graph[i][j]);
            if(graph[i][j]== -1 && i!=j)
                graph[i][j]= INT_MAX;
        }
    }

    floydwarshall(graph,n);
}