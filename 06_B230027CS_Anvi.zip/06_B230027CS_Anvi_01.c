#include <stdio.h>
#include <limits.h>
#include <stdlib.h>
#include <stdbool.h>
int v;

int closestvertex(int dist[],bool spt[]){
    int min=INT_MAX;
    int index;
    for(int i=0;i < v; i++){
        if(spt[i]==false && dist[i] < min){
            min=dist[i];
            index=i;
        }
    }
    return index;
}
void display(int dist[]){
    for(int i=0; i< v; i++){
        printf("%d ",dist[i]);
    }
}
void dijkstra(int **graph, int src){
    int dist[v];
    bool spt[v];

    for(int i=0; i < v; i++){
        dist[i]=INT_MAX;
        spt[i]=false;
    }

    dist[src]=0;
    for(int i=0; i <v-1; i++){
        int u=closestvertex(dist,spt);
        spt[u]=true;

    for(int j=0; j < v; j++){
        if(!spt[j] && graph[u][j] && dist[u]!= INT_MAX && dist[j] > dist[u]+graph[u][j] ){
            dist[j]=dist[u]+graph[u][j];
        }
    }
}
display(dist);
}

int main(){
    scanf("%d",&v);
    int **adjmatrix = (int**)malloc(v* sizeof(int*));
    for(int i=0; i < v ;i++){
        adjmatrix[i]=(int*)malloc(v * sizeof(int));
    for(int j=0; j<v;j++){
        adjmatrix[i][j]=0;
    }
    }

for(int i=0; i <v;i++){
    int start;
    int adjv;
    scanf("%d",&start);
    while(scanf("%d",&adjv)==1){
        adjmatrix[start-1][adjv-1]=1;
        if(getchar()=='\n')
            break;
    }
}

for(int i=0; i< v;i++){
    int start;
    int weight;
    scanf("%d",&start);
    for(int j=0;j <v;j++){
        if(adjmatrix[start-1][j]==1){
            scanf("%d",&weight);
            adjmatrix[start-1][j]=weight;
        }
    }
}

int src;
scanf("%d",&src);
dijkstra(adjmatrix,src-1);

for(int i=0; i<v;i++){
    free(adjmatrix[i]);
}
free(adjmatrix);
}