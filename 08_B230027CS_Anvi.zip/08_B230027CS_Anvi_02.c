#include <stdio.h>
#include <string.h>

#define size 256
#define text_size 10000000
#define pat_size 100000

char text[text_size];
char pat[pat_size];


void badchar(char *pat,int m,int bad[size]){
    for(int i=0;i<size;i++)
        bad[i]=-1;
    for(int i=0;i<m;i++){
        bad[(int)pat[i]]=i;
    }
}

void goodsuff(char *pattern,int m,int *good)
{
    int i=m;
    int j=m+1;
    int borderpos[m+1];
    borderpos[i]=j;
    while(i>0){
        while(j <=m && pat[i-1]!=pat[j-1]){
            if(good[j]==0)  
                good[j]=j-1;
            j=borderpos[j];
        }
        i--;
        j--;
        borderpos[i]=j;
    }
    j=borderpos[0];
    for(i=0;i<=m;i++){
        if(good[i]==0)
            good[i]=j;
        if(i == j)
            j=borderpos[j];
    }
}

int boyermoore(char *text,char *pat){
    int n = strlen(text);
    int m = strlen(pat);
    if(m > n)
        return -1;
    
    int bad[size];
    int good[m+1];

    for(int i=0;i<=m;i++)   
        good[i]=0;
    
    badchar(pat,m,bad);
    goodsuff(pat,m,good);

    int s=0;
    while(s<=n-m){
        int j=m-1;
    while(j>=0 && pat[j]== text[s+j])
        j--;
    if(j <0){
        return s;
        s=s+good[0];
    }else{
        int badshift=j-bad[(int)text[s+j]];
        int goodshift= good[j+1];
        if(badshift > goodshift)
            s=s+badshift;
        else
            s=s+goodshift;
    }
}
return -1;
}

int main(){
    scanf("%[^\n]%*c",text);
     scanf("%[^\n]%*c",pat);

     int res=boyermoore(text,pat);
     printf("%d\n",res);

}